let userQuestions = {};
let userInfo = {
    name: '',
    age: '',
    home: ''
};

document.getElementById('user-input').addEventListener('keypress', function(event) {
    if (event.key === 'Enter') {
        sendMessage();
    }
});

function sendMessage() {
    const userInput = document.getElementById('user-input').value;
    if (userInput.trim() === '') return;

    addMessage(userInput, 'user');
    document.getElementById('user-input').value = '';

    setTimeout(() => {
        botResponse(userInput);
    }, 1000);
}

function addMessage(text, sender) {
    const chatBox = document.getElementById('chat-box');
    const messageDiv = document.createElement('div');
    messageDiv.classList.add('message', sender);

    const avatar = document.createElement('img');
    avatar.classList.add('avatar');
    avatar.src = sender === 'user' ? '02.jpg' : '01.jpg';

    const messageText = document.createElement('div');
    messageText.classList.add('text');
    messageText.innerText = text;

    messageDiv.appendChild(avatar);
    messageDiv.appendChild(messageText);
    chatBox.appendChild(messageDiv);

    chatBox.scrollTop = chatBox.scrollHeight;

    if (sender === 'bot') {
        readOutLoud(text);
    }
}

function getRandomResponse(responses) {
    return responses[Math.floor(Math.random() * responses.length)];
}

function botResponse(userInput) {
    const input = userInput.toLowerCase();

    if (!userQuestions[input]) {
        userQuestions[input] = 0;
    }
    userQuestions[input]++;

    if (userQuestions[input] > 3) {
        addMessage('You are asking too many times! I am getting angry!', 'bot');
        return;
    }

    const responsePool = getResponsePool(input);
    const response = getRandomResponse(responsePool);

    addMessage(response, 'bot');
}

function getResponsePool(input) {
    if (input.includes('how are you') || input.includes('are you fine')) {
        return ['Doing great! How can I help?'];
    } else if (input.includes('this is')) {
        const name = input.split('this is')[1].trim();
        userInfo.name = name;
        return [`Nice to meet you, ${name}!`, `Hello, ${name}!`, `Hi ${name}, how can I assist you?`];
    } else if (input.includes('my name is')) {
        const name = input.split('my name is')[1].trim();
        userInfo.name = name;
        return [`Nice to meet you, ${name}!`, `Hello, ${name}!`, `Hi ${name}, how can I assist you?`];
    } else if (input.includes('name')) {
        return userInfo.name ? [`Your name is ${userInfo.name}.`, `I remember, your name is ${userInfo.name}.`] : ['Wendy here. What is your name?'];
    } else if (input.includes('age')) {
        if (input.includes('my age is')) {
            const age = input.split('my age is')[1].trim();
            userInfo.age = age;
            return [`Got it, you're ${age} years old`];
        }
        return userInfo.age ? [`You are ${userInfo.age} years old.`, `I remember, you are ${userInfo.age} years old.`] : ['I don\'t know your age yet. How old are you?'];
    } else if (input.includes('hi') || input.includes('hello')) {
        const hiMessages = ['Hello! Have a great day'];
        const nameMessage = userInfo.name ? `Hello, ${userInfo.name}! How can I help you today?` : '';
        return nameMessage ? [nameMessage] : hiMessages;
    } else if (input.includes('bye')) {
        const byeMessages = userInfo.name ? [`Good bye, ${userInfo.name}! Have a great day!`] : ['Good bye! Have a great day'];
        return byeMessages;
    } else if (input.includes('thanks wendy') || input.includes('thank you wendy')) {
        const thanksMessages = userInfo.name ? [`You're welcome, ${userInfo.name}!`] : ['You\'re welcome!'];
        return thanksMessages;
    } else if (input.includes('i feel depressed now') || input.includes('i lost my freedom')) {
        return ['I\'m really sorry to hear you\'re feeling this way. Do you want to talk more about what\'s been going on?'];
    } else if (input.includes('i have lot of family problems') || input.includes('i am stressed with my studies and work')) {
        return ['It\'s not a problem dear. You have to balance those things in your life.'];
    } else if (input.includes('i feel so alone like no one understands what I\'m going through')) {
        return ['Feeling alone can be really hard. Even though it might not seem like it, there are people who care and want to understand. Talking about your feelings can sometimes help. Would you like to share more about what\'s been making you feel this way?'];
    } else if (input.includes('i want to find a doctor')) {
        return ['Here are some doctors near you:\nd1.Dr. Senuka\nd2.Dr. Amal\nd3.Dr. Divya'];
    } else if (input.includes('d1')) {
        return ['About Dr. Senuka:\nMBBS, MD, MRCP-UK, PRCP-E\nConsultant Phsychologist\nThe National Hospital, Kurunegala\nAvailable Monday to Friday evenings 6:30 to 11:00 PM'];
    } else if (input.includes('d2')) {
        return ['About Dr. Amal:\nMBBS, MD\nElectrophysiologist\nPhsychology Unit, The National Hospital, Colombo\nAvailable Saturday and Sunday 7:30 to 10:00 PM'];
    } else if (input.includes('d3')) {
        return ['About Dr. Divya:\nMBBS, MD, MRCP\nPhsychologist\nThe National Hospital, Kalutara\nAvailable Monday to Friday evenings 4:30 to 9:00 PM'];
    } else if (input.includes('i need to book an appointment')) {
        return ['To book an appointment with a doctor, select a number:\nb1.Dr. Senuka\nb2.Dr. Amal\nb3.Dr. Divya'];
    } else if (input.includes('b1')) {
        return ['About Dr. Senuka:\n1. Expertise in Phsychology\n2. 15+ years of experience\n3. Available on weekdays\nDo you want to book an appointment?\n4. Yes\n5. No'];
    } else if (input.includes('b2')) {
        return ['About Dr. Amal:\n1. Renowned Electrophysiologist\n2. Phsychology Unit\n3. Available on weekends\nDo you want to book an appointment?\n4. Yes\n5. No'];
    } else if (input.includes('b3')) {
        return ['About Dr. Divya:\n1. Expert in Cardiovascular health\n2. Available on weekdays\nDo you want to book an appointment?\n4. Yes\n5. No'];
    } else if (input.includes('yes')) {
        return ['Thank you! Your appointment has been booked.'];
    } else if (input.includes('no')) {
        return ['Please select a doctor from the list:\n1. Dr. Senuka\n2. Dr. Amal\n3. Dr. Divya'];
    } else if (input.includes('can you give some health tips for me')) {
        return ['Select a doctor for health tips:\nh1.Dr. Senuka\nh2.Dr. Amal\nh3.Dr. Divya'];
    } else if (input.includes('h1')) {
        return ['Health Tips by Dr. Senuka:\n1. Eat a balanced diet\n2. Exercise regularly\n3. Get enough sleep'];
    } else if (input.includes('h2')) {
        return ['Health Tips by Dr. Amal:\n1. Maintain a healthy weight\n2. Stay hydrated\n3. Avoid smoking and alcohol'];
    } else if (input.includes('h3')) {
        return ['Health Tips by Dr. Divya:\n1. Regular check-ups\n2. Manage stress\n3. Stay active'];
    } else if (input.includes('i want to check my symptoms')) {
        return ['Select a doctor for a symptom check:\nS1.Dr. Senuka\nS2.Dr. Amal\nS3.Dr. Divya'];
    } else if (input.includes('s1')) {
        return ['Symptom Check with Dr. Senuka:\n1. Describe your symptoms\n2. Duration of symptoms\n3. Any existing conditions'];
    } else if (input.includes('s2')) {
        return ['Symptom Check with Dr. Amal:\n1. Detail your symptoms\n2. How long have you had them\n3. Any medication being taken'];
    } else if (input.includes('s3')) {
        return ['Symptom Check with Dr. Divya:\n1. Symptoms overview\n2. How long they have persisted\n3. Any known allergies'];
    } else if (input.includes('can i get an insurance info')) {
        return ['Select a doctor for insurance information:\nI1.Dr. Senuka\nI2.Dr. Amal\nI3.Dr. Divya'];
    } else if (input.includes('i1')) {
        return ['Insurance Info from Dr. Senuka:\n1. Accepted plans\n2. Coverage details\n3. Claim process'];
    } else if (input.includes('i2')) {
        return ['Insurance Info from Dr. Amal:\n1. Insurance partnerships\n2. Services covered\n3. Contact for claims'];
    } else if (input.includes('i3')) {
        return ['Insurance Info from Dr. Divya:\n1. Accepted insurances\n2. Benefits provided\n3. How to apply'];
    }
    // Other conditions...
    else if (input.includes('news')) {
        return ['I can\'t fetch the news right now, but you can ask me about something else!', 'News isn\'t my thing, but let\'s chat!', 'How about we talk about something else other than news?'];
    }
    // Other conditions...
    return ['I didn\'t understand that. Could you please rephrase?', 'Can you ask that in a different way?'];
}

function suggestMessage(message) {
    document.getElementById('user-input').value = message;
}

// Text-to-Speech function
function readOutLoud(message) {
    const speech = new SpeechSynthesisUtterance();
    speech.text = message;
    speech.volume = 1;
    speech.rate = 1;
    speech.pitch = 1;

    window.speechSynthesis.speak(speech);
}
function loadVoices() {
    voices = window.speechSynthesis.getVoices();
    femaleVoice = voices.find(voice => voice.name === 'Google US English' && voice.gender === 'female');

    if (!femaleVoice) {
        // If a specific female voice is not found, fall back to any female voice
        femaleVoice = voices.find(voice => voice.gender === 'female');
    }
}

// Ensure voices are loaded
window.speechSynthesis.onvoiceschanged = loadVoices;
loadVoices();

